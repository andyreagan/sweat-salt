# Duration is a proxy, not a variable: a computed decision procedure for sodium replacement during exercise

**Matters Arising from:** McCubbin AJ. Sodium intake for athletes before, during and after exercise: review and recommendations. *Performance Nutrition*. 2025;1:11.

**Article type:** Matters Arising (fallback: Correspondence, if the editor rules that Reviews are out of scope for Matters Arising)

[Author Name]¹

¹ [Institution / affiliation]

Corresponding author: [email]

---

## Abstract

McCubbin's review provides the most complete synthesis to date of sodium replacement evidence for athletes, and its central conclusion, that sodium should be planned relative to fluid balance rather than replaced in isolation, is correct and overdue. The practical decision tree offered in Figure 3, however, does not compute what the review's own text describes. It gates sodium replacement on exercise duration (>4 h) and sweat rate (<1800 mL·h⁻¹) as proxies for the variable that actually governs plasma sodium: the fraction of sweat loss replaced, relative to a crossover fraction that depends only on sweat composition. Rearranging the Kurtz-Nguyen equation shows that this crossover, f\* = 1 − 1.03([Na⁺]sweat + [K⁺]sweat)/([Na⁺]plasma + 23.8), is independent of body mass, total body water and duration. For a whole-body sweat sodium of 80 mmol·L⁻¹ it falls to ~47%, a replacement fraction achievable in events well under 4 h. Duration re-enters only as a magnitude term. We propose a five-step procedure that begins with total fluid loss (sweat rate × duration), applies a maximum tolerable intake rate, derives the achievable replacement fraction and projected body mass deficit, and introduces sweat sodium only at the final step, where it is compared against f\* and, if exceeded, used to compute a dose. The procedure yields two continuous outputs, projected body mass deficit and projected plasma sodium, in place of binary gates. It returns the same answer as the original tree for the majority of athletes, but with a defensible derivation and correct handling of the edge cases the tree currently excludes.

**Keywords:** sodium; hydration; sweat; hyponatraemia; Kurtz-Nguyen; decision support; fluid replacement

---

## Main text

### The review is right; the figure is a shortcut

McCubbin's review [1] reaches a conclusion that the field has needed stated plainly: because sweat is hypotonic to plasma, plasma sodium rises during exercise unless a large fraction of fluid losses is replaced, and sodium replacement is therefore a question about fluid balance, not about sodium balance. The three practitioner questions posed in the text (would >70% fluid replacement help, can the athlete tolerate it, is it practical), together with Equation 3 and the sodium-requirement matrix in Figure 2, already constitute a continuous calculation. Our concern is only that Figure 3, the decision tree most practitioners will actually use, replaces that calculation with categorical proxies, and in doing so excludes a set of realistic sub-4 h scenarios in which the review's own model predicts a falling plasma sodium.

### The crossover fraction depends only on sweat composition

The review notes that, for a whole-body sweat sodium of 50 mmol·L⁻¹, plasma sodium is expected to fall once approximately 70% of fluid losses are replaced. This figure is specific to 50 mmol·L⁻¹. Setting post-exercise plasma sodium equal to pre-exercise in the Kurtz-Nguyen equation [2], with no sodium intake and negligible urine output, gives the replacement fraction at which plasma sodium neither rises nor falls:

f\* = 1 − 1.03 × ([Na⁺]sweat + [K⁺]sweat) / ([Na⁺]plasma,pre + 23.8)

Body mass, total body water and exercise duration all cancel. Only sweat composition and starting plasma sodium survive. Table 1 shows the result across the normative range of whole-body sweat sodium [3].

**Table 1.** Fluid-replacement fraction at which plasma sodium is predicted to stop rising and begin falling, with no sodium intake ([K⁺]sweat 3.5 mmol·L⁻¹, pre-exercise plasma sodium 140 mmol·L⁻¹).

| Whole-body sweat [Na⁺] (mmol·L⁻¹) | Crossover replacement f\* |
|---|---|
| 30 | 79% |
| 40 | 73% |
| 50 | 66% |
| 60 | 60% |
| 70 | 54% |
| 80 | 47% |
| 90 | 41% |

The 70% heuristic is a reasonable central value. It is not a threshold for athletes in the upper quartile of sweat sodium, for whom f\* sits at or below 50%, a replacement fraction that is achievable in events of 2 to 4 h and is routinely exceeded when fluid is freely available.

### A worked counterexample under 4 h

Consider a 70 kg runner (total body water 42 L) with a whole-body sweat sodium of 80 mmol·L⁻¹, within the range reported by Barnes et al. [3], running a hot marathon at 1.4 L·h⁻¹ and drinking 1.0 L·h⁻¹ (71% replacement). Using the Kurtz-Nguyen equation as validated by Baker et al. [4]:

- At 3.0 h: body mass deficit 1.7%, plasma sodium 136.0 mmol·L⁻¹
- At 3.5 h: body mass deficit 2.0%, plasma sodium 135.3 mmol·L⁻¹
- At 4.0 h: body mass deficit 2.3%, plasma sodium 134.6 mmol·L⁻¹

This athlete is within the body mass deficit that most guidelines consider acceptable, is under the 4 h gate, and is at the floor of the clinical reference range for plasma sodium. Figure 3 directs them to "season to taste". The sodium required to hold plasma sodium at 140 mmol·L⁻¹ in the 3 h case is ~160 mmol (3.7 g), which at their fluid intake corresponds to ~53 mmol·L⁻¹ or ~123 mg·100 mL⁻¹, at the upper limit of palatability the review itself identifies. This is a case where the athlete needs to know, and where sweat composition testing does add information.

### Duration matters for magnitude, not direction

We do not argue that duration is irrelevant. Being above f\* determines only that plasma sodium is falling; the size of the fall scales approximately with (f − f\*) × cumulative sweat volume / total body water, and cumulative sweat volume is rate × duration. The 4 h gate is therefore a defensible approximation of "long enough for the drift to become clinically meaningful" at typical sweat sodium concentrations. Our point is that an approximation should not be the top of the decision tree when the underlying quantity can be computed from the same inputs the tree already requires. A tree that outputs the projected end-of-event plasma sodium, rather than a binary gate, handles both the central case and the edge cases without additional data.

### The high-sweat-rate case is already handled, and correctly

The review's worked example of a rugby player at 2.5 L·h⁻¹ and 60 mmol·L⁻¹ illustrates that very high sweat rates do not create a sodium problem, because the athlete cannot replace enough fluid to cross f\*. We agree, and our procedure reproduces the review's figures (144 mmol·L⁻¹ with no sodium; 148 mmol·L⁻¹ with full replacement). The athletes the current tree fails are not heavy sweaters. They are moderate sweaters with high sweat sodium who drink well, in events of 2.5 to 4 h.

### Proposed procedure

We propose that Figure 3 be replaced with a computation that takes five inputs (sweat rate, duration, body mass, maximum tolerable fluid intake rate, acceptable body mass deficit) and introduces sweat sodium only at the final step:

1. **Total fluid loss** = sweat rate × duration (corrected for onset ramp where measured).
2. **Required replacement fraction** = (total loss − acceptable deficit) / total loss, where acceptable deficit = target % × body mass. This is the review's Equation 3.
3. **Achievable replacement fraction** = (maximum tolerable intake × duration) / total loss, capped at 1. Gastric emptying and intestinal absorption during exercise constrain this to roughly 1.0 to 1.5 L·h⁻¹ in most individuals [5], and it is trainable.
4. **Operating point** = the lesser of steps 2 and 3. Output the projected body mass deficit at the operating point. If achievable < required, the athlete is fluid-limited; hydration is the binding constraint and plasma sodium will rise regardless of sodium intake.
5. **Compare the operating point to f\*** for the athlete's sweat composition. Below f\*: sodium intake can be set by palatability. Above f\*: use Equation 2 of the review to compute the sodium dose that holds plasma sodium stable at the operating point, and output the projected end-of-event plasma sodium with and without that dose.

Steps 1 to 4 require no sweat composition data. Step 5 is the first point at which testing becomes informative, which preserves the review's conclusion that testing is unnecessary for most athletes while making explicit, and computable, the criterion for when it is not.

### Limitations

This is a modelling argument, as is the review's. No outcome data exist at the operating points described, and the review correctly notes uncertainty about whether purposeful sodium replacement in the 70 to 100% window spares plasma volume or osmotically inactive sodium stores. The maximum tolerable intake rate is an individual parameter with limited normative data and should be measured rather than assumed. The acceptable body mass deficit is contested [6] and should be treated as a user input rather than a constant. Our claim is for better decision logic, not for better evidence.

---

## List of abbreviations

f\*: crossover fluid-replacement fraction; [Na⁺]sweat: whole-body sweat sodium concentration; [K⁺]sweat: whole-body sweat potassium concentration; [Na⁺]plasma: plasma sodium concentration; TBW: total body water

## Declarations

**Ethics approval and consent to participate:** Not applicable.

**Consent for publication:** Not applicable.

**Availability of data and materials:** All calculations are reproducible from the equations given in the text. An interactive implementation of the proposed procedure is available at [URL / repository, to be added].

**Competing interests:** The author(s) declare that they have no competing interests. [Amend if the author has any commercial relationship with hydration products, sweat testing services, or electrolyte manufacturers.]

**Funding:** No funding was received for the preparation of this manuscript.

**Authors' contributions:** [Initials] conceived the argument, performed the calculations, and wrote the manuscript.

**Acknowledgements:** A large language model (Claude, Anthropic) was used to assist with drafting and with verifying the algebraic rearrangement of the Kurtz-Nguyen equation. All calculations were independently checked by the author, who takes full responsibility for the content.

---

## References

1. McCubbin AJ. Sodium intake for athletes before, during and after exercise: review and recommendations. Performance Nutrition. 2025;1:11. doi:10.1186/s44410-025-00011-9.
2. Kurtz I, Nguyen MK. A simple quantitative approach to analyzing the generation of the dysnatremias. Clin Exp Nephrol. 2003;7(2):138-43.
3. Barnes KA, Anderson ML, Stofan JR, Dalrymple KJ, Reimel AJ, Roberts TJ, et al. Normative data for sweating rate, sweat sodium concentration, and sweat sodium loss in athletes: an update and analysis by sport. J Sports Sci. 2019;37(20):2356-66.
4. Baker LB, Lang JA, Kenney WL. Quantitative analysis of serum sodium concentration after prolonged running in the heat. J Appl Physiol. 2008;105(1):91-9.
5. Costill DL, Saltin B. Factors limiting gastric emptying during rest and exercise. J Appl Physiol. 1974;37(5):679-83.
6. James LJ, Funnell MP, James RM, Mears SA. Does hypohydration really impair endurance performance? Methodological considerations for interpreting hydration research. Sports Med. 2019;49(Suppl 2):103-14.

---

*Notes for the author before submission:*

- *The journal strongly encourages contacting the original author first. A short email to McCubbin (alan.mccubbin@monash.edu, per the paper) with the f\* derivation and Table 1 may get a more useful response than the formal route, and would not preclude submitting afterward.*
- *Verify reference 5 against the original; the 1.0–1.5 L·h⁻¹ range is a synthesis of several sources and a more recent review on fluid absorption during exercise may be a stronger citation.*
- *If a figure is wanted, the five-step procedure above is the figure. A flowchart version is provided separately.*
- *Word count of main text is approximately 1,050. Matters Arising has no stated limit, but shorter is better for this format.*
